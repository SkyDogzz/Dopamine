# Historique documentaire — Dopamine Survivor

| Version | Fichier | Fiabilité |
|---|---|---|
| 1.0 | `GDD_v1.0_RECONSTITUTION.md` | Reconstitution thématique à partir de l’historique et v1.5, pas original |
| 1.1 | `GDD_v1.1_RECONSTITUTION.md` | Ajouts historiques reconstruits, pas original |
| 1.2 | `GDD_v1.2_RECONSTITUTION.md` | Achievement Mastery, contenu détaillé extrait de v1.5 |
| 1.3 | `GDD_v1.3_RECONSTITUTION.md` | Endless Armorless, contenu détaillé extrait de v1.5 |
| 1.4 | `GDD_v1.4_RECONSTITUTION.md` | Sandbox Lab, contenu détaillé extrait de v1.5 |
| 1.5 | `GDD_v1.5.md` | Texte consolidé existant, référence |
| 1.6 | `GDD_v1.6_DELTA.md` | Delta v1.6 explicite |
| 1.6 | `GDD_v1.6_RECONSTITUTION_COMPLETE.md` | v1.5 intégral + delta, NON fusion normalisée |

## Règle d'interprétation

Les documents v1.0–v1.4 sont des **reconstructions documentaires**, non des originaux historiques. Les sections reprises du GDD v1.5 peuvent contenir des ajustements ultérieurs : ne pas les utiliser comme preuve qu'une formulation ou valeur existait déjà dans une ancienne version. Les jalons identifiés sont v1.0 fondations, v1.1 systèmes/balancing, v1.2 Achievement Mastery, v1.3 Endless Armorless, v1.4 Sandbox Lab, v1.5 consolidation, v1.6 gameplay delta et Magnet Heart.
